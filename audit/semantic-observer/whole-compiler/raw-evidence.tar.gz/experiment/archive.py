"""Retain exact experiment files and compare every archived byte to its source."""
import gzip
import hashlib
import io
import json
from pathlib import Path
import tarfile

OUT = Path(__file__).resolve().parent
ROOT = OUT.parents[1]
AUDIT = ROOT / "nox-observer/audit/semantic-observer/whole-compiler"


def sha(data):
    return hashlib.sha256(data).hexdigest()


def require(condition, message):
    if not condition:
        raise ValueError(message)


launch = json.loads((OUT / "launch.json").read_bytes())
require(launch["status"] != "preflight" and launch["status"] != "preflight-passed", "experiment still in flight")
sources = {"experiment/" + str(path.relative_to(OUT)): path
           for path in OUT.rglob("*") if path.is_file()}
sources.update({
    "reference/frozen-s1-c2-to-c3.json": ROOT / "measurements/lexer-v9-c2-to-c3.json",
    "reference/actual-ci-c2-producer.json": Path(launch["producer"]["path"]),
    "reference/actual-ci-platform-receipt.json": Path(launch["producer"]["path"]).parent.parent / "receipt.json",
    "reference/actual-ci-files.json": Path(launch["producer"]["path"]).parent.parent / "files.json",
    "reference/actual-ci-api-artifact.json": ROOT / "measurements/ci-split-readonly/artifact-10948746458.json",
    "reference/ci-c2-copy-origin.json": ROOT / "measurements/selfhost-cli-guide/receipt.json",
    "reference/probe-native-closure.py": Path(launch["probe"]["path"]),
    "reference/check-selfhost-fixed-point.py": Path(launch["checker"]["path"]),
    "reference/integration-pins.json.gz": ROOT / "nox-observer/audit/semantic-observer/joy-integration/pins.json.gz",
})
AUDIT.mkdir(parents=True, exist_ok=False)
archive = AUDIT / "raw-evidence.tar.gz"
rows = []
with archive.open("xb") as output:
    with gzip.GzipFile(fileobj=output, mode="wb", filename="", mtime=0) as compressed:
        with tarfile.open(fileobj=compressed, mode="w", format=tarfile.PAX_FORMAT) as retained:
            for name, source in sorted(sources.items()):
                require(not source.is_symlink(), "refuse symlink: " + str(source))
                raw = source.read_bytes()
                info = tarfile.TarInfo(name)
                info.size, info.mode, info.mtime = len(raw), 0o644, 0
                retained.addfile(info, io.BytesIO(raw))
                rows.append(dict(path=name, original_path=str(source), bytes=len(raw), sha256=sha(raw)))
expected = {row["path"]: row for row in rows}
seen = set()
with tarfile.open(archive, "r:gz") as retained:
    for member in retained:
        require(member.isfile() and member.name in expected and member.name not in seen, "unexpected archive member")
        seen.add(member.name)
        raw = retained.extractfile(member).read()
        row = expected[member.name]
        require(len(raw) == row["bytes"] and sha(raw) == row["sha256"], "archived bytes changed")
        require(raw == Path(row["original_path"]).read_bytes(), "archive differs from raw source")
require(seen == set(expected), "incomplete archive")
manifest = dict(schema="nox/whole-compiler-raw-evidence/v1", scope="Exact raw file bytes; archive headers normalized, file content unchanged",
                archive=dict(path=archive.name, bytes=archive.stat().st_size, sha256=sha(archive.read_bytes())),
                file_count=len(rows), raw_bytes=sum(row["bytes"] for row in rows), files=rows,
                verification="Every ordinary-file member compared byte-for-byte to original after compression; exact member set")
with (AUDIT / "files.json").open("x", encoding="utf-8") as output:
    json.dump(manifest, output, indent=2)
    output.write("\n")
for name in ("launch.json", "verification.json", "c2-to-c3.json"):
    source = OUT / name
    if source.exists():
        with (AUDIT / (name + ".gz")).open("xb") as output:
            output.write(gzip.compress(source.read_bytes(), mtime=0))
print(json.dumps({key: manifest[key] for key in ("archive", "file_count", "raw_bytes", "verification")}))
